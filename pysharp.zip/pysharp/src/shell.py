from __init__ import helloworld_app

helloworld_app()