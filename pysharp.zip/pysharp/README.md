# 🔥 PySharp

**`Python Child (Python/Framework/Language)`**

Trying to make Python simpler is not easy. Even with a full building filled up with
Full-Stack developers and that's why PySharp/ Py# is alive. Name from C# and Origin
from Python, it tries to break down Python to help the average person who wants to 
code with easy grammar and words.